let CARS = [];




// $(document).ready(function(){
//     alert('document is ready');
// });