$("#btnCreateCar").click(function() {
    // implement button listener
    let brand = $("#brand").val();
    let model = $("#model").val();
    let color = $("#color").val();
    let mileage = $("#mileage").val();
    let isBroken = $("#isBroken").prop("checked");
    
    mileage = Number(mileage);
    let newCar = createCar(brand, color, model, mileage, isBroken);
    addToArray(newCar);
    displayCar(newCar);
});

function createCar(brandValue, colorValue, modelValue, mileageValue, isBroken) {
    let newCar = {
        brand: brandValue,
        model: modelValue,
        color: colorValue,
        mileage: mileageValue,
        broken: isBroken
    };    
    return newCar;
}

function displayCar(car){
    let carJSON = JSON.stringify(car);
    document.getElementById("jsonString").innerText = carJSON;
}

function addToArray(car){
    CARS.push(car);
    saveCarsToLocalStorage();
    console.log(CARS);
}

function saveCarsToLocalStorage(){
    localStorage.setItem('cars', JSON.stringify(CARS));
}

function loadCarsFromLocalStorage(){
    CARS = JSON.parse(localStorage.getItem('cars'));
}





// let car1 = {
//     type: 'Fiat',
//     model: 500,
//     color: 'White',
//     broken: false
// };




// function showMessage(msg){
//     alert('Funkcija sako: ' + msg);
   
// }

// function test(){
//     if(typeof car1 === 'undefined'){
//         alert('CAR1 is undefined!');
//     }else{
//         if(car1){
//             alert('Car is OK');
//         }else{
//             alert('Car is Null');
//         }
//     }
// }
 
// function sum(a, b){
//      if(typeof a == 'number'){
//          return 0;
//      }else{
//          return a + b;
//      }
// }